q1 = """Is Python case sensitive when dealing with Identifiers?
a. Yes
b. No
c. Machine Dependent
d. None\n"""

q2 = """Given the following state:
x = 10
y = 5
What is the value bound to x?
a. y
b. 10
c. 5
d. x\n"""

q3 = """Which one of these is floor division?
a. /
b. //
c. %
d. None\n"""

q4 = """What is the output of this 3*1**3?
a. 27
b. 9
c. 3
d. 1\n"""

q5 = """"a"+"bc"=?
a. a
b. bc
c. bca
d. abc\n"""

q6 = """Given the following state:
x = 1
y = 2
What is the value bound to y?
a. 1
b. y
c. The whole state is bound to y
d. 2\n"""

q7 = """Given the following state:
x = 10
y = 5
Which of the following code snippets would change the state to the following state?
x = 1
y = 2
\n
a. x = 1  | y = 2
b. x = 2  | y = 1
c. x = 10 | y = 5
d. y = 1  | y = 2\n"""
